console.log("welcome to typescript");

var message:string="Hello World"
console.log(message)
