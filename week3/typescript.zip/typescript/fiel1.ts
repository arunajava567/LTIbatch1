export let age : number = 20;

//module creation n exporting