var i: number = 2;
do {
    console.log("Block statement execution no." + i )
    i++;
} while ( i < 4)

console.log("for loop");
for(let x=1;x<=10;x++) {
    console.log(x);
}
console.log(" while  loop");
var y=1;
while(y<20) {

    console.log(y);
    y+=1;
}