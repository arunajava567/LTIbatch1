import {age} from './fiel1'  //module importing 
console.log(age);