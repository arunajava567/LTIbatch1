class Greeting{
		greet():void  
		{
		console.log("Hello World!!!")
	   }
}
var obj =new Greeting();
obj.greet();

//npm install typescript
//tsc filename.ts   => compile ts file
//node filename.js   => run your ts file