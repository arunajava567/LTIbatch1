
var name1:string="John";
var score1:number =50;
var score2:number =42.50
var sum = score1 + score2 
console.log("name"+name1)
console.log("first score: "+score1)
console.log("second score: "+score2)
console.log("sum of the scores: "+sum)