document.writeln("<h1> Welcome to JS </h1>");
window.alert("JS program");
alert("Welcome to JS");
var a=prompt("enter a");
var b=prompt("enter b");
var c=parseInt(a)+parseInt(b);
document.writeln(c);
confirm("are you sure ");