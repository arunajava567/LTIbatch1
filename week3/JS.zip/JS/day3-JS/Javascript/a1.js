console.log("welcome to Serverside Javascript");
var a=50;
var b=20;
console.log(a+b);
for(var i=1;i<=10;i++)
 console.log(i);

 if(a>b)
  console.log("a is big");
  else
  console.log("b is big");