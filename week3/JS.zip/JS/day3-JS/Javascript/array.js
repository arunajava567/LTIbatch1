
var a=["java","spring","hibernate"];

var b=new Array("js","css","html","angular");
for(var i=0;i<a.length;i++) {
    console.log(a[i]);
}
for(var i=0;i<b.length;i++) {
    console.log(b[i]);
}