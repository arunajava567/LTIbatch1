// node -v
// npm -v 
// running js files on node.js
//runtime environment
var  s=new String("Capgemini");
console.log(s);
console.log(s.length);
console.log(Math.max(34,56,78,56));
var d=new Date();
console.log(d.getDay);