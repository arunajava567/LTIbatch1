
           alert("Welcome");
           var marks=prompt("enter marks");
           if(marks>90)
               alert("Great");
           else
                 alert("poor");