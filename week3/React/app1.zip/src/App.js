import React,{ Component} from 'react'
import Login from './Login'
//class 
// functional
/* stateless
function App() {
  return (
    <div className="App">
     
     <h1> My first React  Functional Application</h1>
    </div>
  );
}

export default App;*/
class App extends Component {
//stateful
 constructor() {
   super();
   this.state={name:"LTIUser"}; //state , mutable ,props
 }
  render(){
    return(
    <div>
       <h2> { this.state.name} </h2>
       <h1> My first class component</h1>
       <div>
         <Login city='Hyderabad'/>
         <Signup/>
       </div>
    </div>

    );
  }

}

function Signup()  {
 return(
  <div className="App">
     
  <h1>  Signup</h1>

 </div>
 );
}




export default App;
