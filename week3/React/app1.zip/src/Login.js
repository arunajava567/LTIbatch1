import React,{ Component } from 'react'
class Login extends Component{

    render() {
      return(  //props ,immutable 
        <div>  {this.props.city}
           <h1> Login Component</h1></div>
      );
    }
  
}
export default Login;