import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust',
  templateUrl: './cust.component.html',
  styleUrls: ['./cust.component.css']
})
export class CustComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
