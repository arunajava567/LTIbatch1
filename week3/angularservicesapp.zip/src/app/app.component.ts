import { Component } from '@angular/core';
import { MyserviceService } from './myservice.service';
import { HelloServiceService} from './hello-service.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularservicesapp';
  todaydate;
  msg;
   constructor(private myservice: MyserviceService, private helloService :HelloServiceService) {}
   ngOnInit() { 
      this.msg=this.helloService.sayHelo();
      this.todaydate = this.myservice.showTodayDate(); //DI
   } 

}
