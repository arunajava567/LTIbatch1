import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HelloServiceService {

  constructor() { }
  sayHelo() {
   // alert("Welcome to Services");
    return "Welcome to Services";
  }
}
