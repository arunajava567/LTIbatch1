import { Component } from '@angular/core';
import { MyserviceService } from './myservice.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 7 Project!';
  public persondata = [];
  constructor(private myservice: MyserviceService) {}
  ngOnInit() {
    //subscribe to server URL/endpoint to get loaded with backend data
     this.myservice.getData().subscribe((data) => {
        this.persondata = Array.from(Object.keys(data), k=>data[k]);
        console.log(this.persondata);
     });
  }

}
