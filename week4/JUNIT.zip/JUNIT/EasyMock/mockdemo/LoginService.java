package com.capgemini.lesson07.mockdemo;

public interface LoginService {
boolean login(String username, String password);
}
