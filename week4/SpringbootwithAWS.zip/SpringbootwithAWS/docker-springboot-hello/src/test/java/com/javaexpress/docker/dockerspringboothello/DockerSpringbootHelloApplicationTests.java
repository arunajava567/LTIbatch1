package com.javaexpress.docker.dockerspringboothello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSpringbootHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
