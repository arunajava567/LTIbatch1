# spring-boot2-jpa-crud-example
spring boot2 jpa crud REST APIs example


Below is the step by step article which explained this Spring boot 2 JPA CRUD Restful apis example :


http://www.javaguides.net/2018/09/spring-boot-2-jpa-mysql-crud-example.html
