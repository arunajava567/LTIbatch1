package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Post;
import com.example.jpa.repository.PostRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//import javax.validation.Valid;

@RestController
public class PostController {
	private static final Logger logger = LoggerFactory.getLogger(PostController.class);

    @Autowired
    private PostRepository postRepository;

    @GetMapping("/posts")
    public List<Post> getAllPosts()  { //Pageable pageable) { //pagination no of rows are more than pagination and sorting 
      
    	logger.info(" my post conroller===================");
    	return postRepository.findAll();
    }

    
    /*
     * {"content":[{"id":1,"title":"oracle12","description":"databse","content":"Relational Databse"},
     * {"id":2,"title":"jpa12","description":"databse","content":"Relational Databse"}],"pageable":{"sort":{"sorted":false,"unsorted":true},"offset":0,"pageNumber":0,"pageSize":20,"unpaged":false,"paged":true},"last":true,"totalElements":2,"totalPages":1,"size":20,"number":0,"sort":{"sorted":false,"unsorted":true},"numberOfElements":2,"first":true}
     * 
     */
    @PostMapping("/posts")
    public Post createPost( @RequestBody Post post) {
        return postRepository.save(post);
    }

    @PutMapping("/posts/{postId}")
    public Post updatePost(@PathVariable Long postId,  @RequestBody Post postRequest) {
        return postRepository.findById(postId).map(post -> {
            post.setTitle(postRequest.getTitle());
            post.setDescription(postRequest.getDescription());
            post.setContent(postRequest.getContent());
            return postRepository.save(post);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }


    @DeleteMapping("/posts/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable Long postId) {
        return postRepository.findById(postId).map(post -> {
            postRepository.delete(post);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

}
