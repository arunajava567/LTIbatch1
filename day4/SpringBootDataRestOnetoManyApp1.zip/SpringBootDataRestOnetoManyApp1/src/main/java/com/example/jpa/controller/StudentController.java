package com.example.jpa.controller;

import javax.persistence.Column;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Comment;
import com.example.jpa.model.Student;
import com.example.jpa.repository.CommentRepository;
import com.example.jpa.repository.PostRepository;
import com.example.jpa.repository.StudentRepository;

@RestController
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

	/*
	 * @Autowired private PostRepository postRepository;
	 * 
	 * @GetMapping("/posts/{postId}/comments") public Page <Comment>
	 * getAllCommentsByPostId(@PathVariable (value = "postId") Long postId, Pageable
	 * pageable) { // return commentRepository.findAll(); return
	 * commentRepository.findByPostId(postId, pageable); }
	 */

    @PostMapping("/student")
    public Student createComment( @RequestBody Student student) {
        return   studentRepository.save(student);
      
    }
/*
    {
    "studentId":"1",
    "name":"abc",
    	
    {	
    "addressId":"1",
    "street":"s1",
	"city":"c1",
	"state:":st1"",
	"zipCode":"2222"
    }
    }
    
    */
}


/*
  {
    "studentId":"1",
    "name":"abc",
    	
    "address":{	
    	"addressId":"1",
		 "street":"s1",
		"city":"c1",
		"state:":"st1",
		"zipCode":"2222"
	     }
	
    }
*/