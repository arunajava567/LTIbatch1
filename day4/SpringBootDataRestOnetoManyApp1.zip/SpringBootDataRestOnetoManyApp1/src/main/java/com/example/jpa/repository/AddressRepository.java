package com.example.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jpa.model.Address;
import com.example.jpa.model.Student;

public interface AddressRepository  extends JpaRepository<Address, Integer> {

}
