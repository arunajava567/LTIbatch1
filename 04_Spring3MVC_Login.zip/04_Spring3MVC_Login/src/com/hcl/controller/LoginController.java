package com.hcl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller    //@Component
public class LoginController {

	public LoginController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping("/hello")
	public ModelAndView display(HttpServletRequest request,HttpServletResponse res){
		
		String name=request.getParameter("name");  
        String password=request.getParameter("password");
        
        if(password.equals("password-1")){
        	
        	String message123 ="Hello "+name;
        	                          //1. jsp name  2.attribute name on jsp 3. model
        	return new ModelAndView("hellopage","message345",message123);
        }
        else{
        	
        	return new ModelAndView("errorpage","message","Sorry username and password error");
        }
		
	}
}
